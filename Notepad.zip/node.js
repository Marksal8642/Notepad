console.log(__dirname)
setInterval(() => {
console.log('hello world')
}, 1000)